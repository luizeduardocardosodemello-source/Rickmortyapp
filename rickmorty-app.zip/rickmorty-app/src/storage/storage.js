import AsyncStorage from '@react-native-async-storage/async-storage';

export const KEYS = {
  FAVORITES: '@rm:favorites',
  THEME: '@rm:theme',
};

export async function saveItem(key, value) {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn('Erro ao salvar no AsyncStorage', e);
  }
}

export async function loadItem(key, fallback = null) {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw !== null ? JSON.parse(raw) : fallback;
  } catch (e) {
    console.warn('Erro ao ler do AsyncStorage', e);
    return fallback;
  }
}
