import React from 'react';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { adaptNavigationTheme, IconButton } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import HomeScreen from '../screens/HomeScreen';
import FavoritesScreen from '../screens/FavoritesScreen';
import DetailsScreen from '../screens/DetailsScreen';
import { useApp } from '../context/AppContext';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const { LightTheme, DarkTheme: PaperDarkNav } = adaptNavigationTheme({
  reactNavigationLight: DefaultTheme,
  reactNavigationDark: DarkTheme,
});

// Navegação por abas (Personagens | Favoritos)
function Tabs() {
  const { favorites, isDark, toggleTheme } = useApp();

  return (
    <Tab.Navigator
      screenOptions={{
        headerRight: () => (
          <IconButton
            icon={isDark ? 'white-balance-sunny' : 'moon-waning-crescent'}
            onPress={toggleTheme}
          />
        ),
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          title: 'Personagens',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="account-group" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Favorites"
        component={FavoritesScreen}
        options={{
          title: 'Favoritos',
          tabBarBadge: favorites.length > 0 ? favorites.length : undefined,
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="heart" color={color} size={size} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

// Stack principal: Tabs -> Detalhes
export default function Navigation({ theme }) {
  const { isDark } = useApp();
  const navTheme = {
    ...(isDark ? PaperDarkNav : LightTheme),
    colors: {
      ...(isDark ? PaperDarkNav.colors : LightTheme.colors),
      primary: theme.colors.primary,
    },
  };

  return (
    <NavigationContainer theme={navTheme}>
      <Stack.Navigator>
        <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
        <Stack.Screen
          name="Details"
          component={DetailsScreen}
          options={({ route }) => ({ title: route.params.character.name })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
