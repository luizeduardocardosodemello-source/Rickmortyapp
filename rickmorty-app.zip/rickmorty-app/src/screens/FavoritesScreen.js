import React from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import { Button, Text, useTheme } from 'react-native-paper';
import CharacterCard from '../components/CharacterCard';
import { useApp } from '../context/AppContext';

export default function FavoritesScreen({ navigation }) {
  const theme = useTheme();
  const { favorites, clearFavorites } = useApp();

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      {favorites.length === 0 ? (
        <View style={styles.center}>
          <Text variant="titleMedium">Nenhum favorito ainda 💔</Text>
          <Text style={{ marginTop: 8, marginBottom: 16 }}>
            Toque no coração de um personagem para salvá-lo.
          </Text>
          <Button mode="contained" onPress={() => navigation.navigate('Home')}>
            Ver personagens
          </Button>
        </View>
      ) : (
        <FlatList
          data={favorites}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <CharacterCard
              character={item}
              onPress={() => navigation.navigate('Details', { character: item })}
            />
          )}
          ListFooterComponent={
            <Button style={styles.clear} icon="delete" onPress={clearFavorites}>
              Limpar favoritos
            </Button>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  clear: { margin: 16 },
});
