import React, { useEffect, useState } from 'react';
import { Image, ScrollView, StyleSheet, View } from 'react-native';
import { ActivityIndicator, Chip, Divider, FAB, List, Text, useTheme } from 'react-native-paper';
import { fetchEpisode } from '../services/api';
import { useApp } from '../context/AppContext';

export default function DetailsScreen({ route }) {
  const { character } = route.params;
  const theme = useTheme();
  const { isFavorite, toggleFavorite } = useApp();
  const [episode, setEpisode] = useState(null);
  const [loadingEp, setLoadingEp] = useState(true);

  const fav = isFavorite(character.id);

  // Segunda chamada à API: primeiro episódio em que o personagem apareceu
  useEffect(() => {
    let active = true;
    fetchEpisode(character.episode[0])
      .then((ep) => active && setEpisode(ep))
      .catch(() => active && setEpisode(null))
      .finally(() => active && setLoadingEp(false));
    return () => { active = false; };
  }, [character]);

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <ScrollView contentContainerStyle={styles.content}>
        <Image source={{ uri: character.image }} style={styles.image} />
        <Text variant="headlineMedium" style={styles.name}>{character.name}</Text>

        <View style={styles.chips}>
          <Chip icon="heart-pulse" style={styles.chip}>{character.status}</Chip>
          <Chip icon="dna" style={styles.chip}>{character.species}</Chip>
          <Chip icon="gender-male-female" style={styles.chip}>{character.gender}</Chip>
        </View>

        <Divider style={{ marginVertical: 12 }} />

        <List.Item
          title="Origem"
          description={character.origin?.name}
          left={(p) => <List.Icon {...p} icon="earth" />}
        />
        <List.Item
          title="Última localização"
          description={character.location?.name}
          left={(p) => <List.Icon {...p} icon="map-marker" />}
        />
        <List.Item
          title="Episódios"
          description={`Aparece em ${character.episode.length} episódio(s)`}
          left={(p) => <List.Icon {...p} icon="television-classic" />}
        />
        <List.Item
          title="Primeira aparição"
          description={
            loadingEp ? 'Carregando...' : episode ? `${episode.episode} - ${episode.name}` : 'Indisponível'
          }
          left={(p) =>
            loadingEp ? <ActivityIndicator style={{ marginLeft: 16 }} /> : <List.Icon {...p} icon="play-circle" />
          }
        />
      </ScrollView>

      <FAB
        icon={fav ? 'heart' : 'heart-outline'}
        label={fav ? 'Favoritado' : 'Favoritar'}
        style={styles.fab}
        onPress={() => toggleFavorite(character)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 100 },
  image: { width: '100%', aspectRatio: 1, borderRadius: 16 },
  name: { marginTop: 16, textAlign: 'center' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', marginTop: 12 },
  chip: { margin: 4 },
  fab: { position: 'absolute', right: 16, bottom: 24 },
});
