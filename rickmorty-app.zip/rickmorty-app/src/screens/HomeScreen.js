import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import { ActivityIndicator, Button, Searchbar, Text, useTheme } from 'react-native-paper';
import CharacterCard from '../components/CharacterCard';
import { fetchCharacters } from '../services/api';

export default function HomeScreen({ navigation }) {
  const theme = useTheme();
  const [query, setQuery] = useState('');
  const [characters, setCharacters] = useState([]);
  const [page, setPage] = useState(1);
  const [hasNext, setHasNext] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState(null);
  const requestId = useRef(0); // evita resposta antiga sobrescrever a nova

  const load = useCallback(async (pageNum, name, replace) => {
    const id = ++requestId.current;
    setError(null);
    replace ? setLoading(true) : setLoadingMore(true);
    try {
      const { results, hasNext: next } = await fetchCharacters({ page: pageNum, name });
      if (id !== requestId.current) return;
      setCharacters((prev) => (replace ? results : [...prev, ...results]));
      setHasNext(next);
      setPage(pageNum);
    } catch (e) {
      if (id === requestId.current) setError(e.message);
    } finally {
      if (id === requestId.current) {
        setLoading(false);
        setLoadingMore(false);
      }
    }
  }, []);

  // Busca com debounce de 400ms
  useEffect(() => {
    const t = setTimeout(() => load(1, query, true), 400);
    return () => clearTimeout(t);
  }, [query, load]);

  const onEndReached = () => {
    if (hasNext && !loading && !loadingMore) load(page + 1, query, false);
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Searchbar
        placeholder="Buscar personagem..."
        value={query}
        onChangeText={setQuery}
        style={styles.search}
      />

      {loading ? (
        <ActivityIndicator style={styles.center} size="large" />
      ) : error ? (
        <View style={styles.center}>
          <Text variant="bodyLarge" style={{ marginBottom: 12 }}>{error}</Text>
          <Button mode="contained" onPress={() => load(1, query, true)}>
            Tentar novamente
          </Button>
        </View>
      ) : (
        <FlatList
          data={characters}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <CharacterCard
              character={item}
              onPress={() => navigation.navigate('Details', { character: item })}
            />
          )}
          onEndReached={onEndReached}
          onEndReachedThreshold={0.5}
          ListEmptyComponent={
            <Text style={styles.empty}>Nenhum personagem encontrado.</Text>
          }
          ListFooterComponent={
            loadingMore ? <ActivityIndicator style={{ margin: 16 }} /> : null
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  search: { margin: 16, marginBottom: 8 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  empty: { textAlign: 'center', marginTop: 40 },
});
