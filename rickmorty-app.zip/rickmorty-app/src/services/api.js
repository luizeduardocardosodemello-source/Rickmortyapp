const BASE_URL = 'https://rickandmortyapi.com/api';

// Lista paginada de personagens, com busca opcional por nome
export async function fetchCharacters({ page = 1, name = '' } = {}) {
  const params = new URLSearchParams({ page: String(page) });
  if (name.trim()) params.append('name', name.trim());

  const res = await fetch(`${BASE_URL}/character?${params.toString()}`);

  // A API responde 404 quando a busca não encontra nada
  if (res.status === 404) return { results: [], hasNext: false };
  if (!res.ok) throw new Error(`Erro ao buscar personagens (${res.status})`);

  const data = await res.json();
  return { results: data.results, hasNext: Boolean(data.info?.next) };
}

// Busca um episódio a partir da URL que vem no objeto do personagem
export async function fetchEpisode(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Erro ao buscar episódio (${res.status})`);
  return res.json();
}
