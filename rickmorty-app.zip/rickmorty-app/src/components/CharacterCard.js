import React from 'react';
import { StyleSheet } from 'react-native';
import { Card, IconButton } from 'react-native-paper';
import { useApp } from '../context/AppContext';

export default function CharacterCard({ character, onPress }) {
  const { isFavorite, toggleFavorite } = useApp();
  const fav = isFavorite(character.id);

  return (
    <Card style={styles.card} onPress={onPress}>
      <Card.Cover source={{ uri: character.image }} />
      <Card.Title
        title={character.name}
        subtitle={`${character.species} • ${character.status}`}
        right={() => (
          <IconButton
            icon={fav ? 'heart' : 'heart-outline'}
            iconColor={fav ? '#e53935' : undefined}
            onPress={() => toggleFavorite(character)}
          />
        )}
      />
    </Card>
  );
}

const styles = StyleSheet.create({
  card: { marginHorizontal: 16, marginVertical: 8 },
});
