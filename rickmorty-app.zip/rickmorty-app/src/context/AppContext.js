import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { KEYS, loadItem, saveItem } from '../storage/storage';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [favorites, setFavorites] = useState([]);
  const [isDark, setIsDark] = useState(false);
  const [ready, setReady] = useState(false);

  // Carrega dados salvos ao abrir o app
  useEffect(() => {
    (async () => {
      const [favs, dark] = await Promise.all([
        loadItem(KEYS.FAVORITES, []),
        loadItem(KEYS.THEME, false),
      ]);
      setFavorites(favs);
      setIsDark(dark);
      setReady(true);
    })();
  }, []);

  // Persiste sempre que mudar (só depois do carregamento inicial)
  useEffect(() => {
    if (ready) saveItem(KEYS.FAVORITES, favorites);
  }, [favorites, ready]);

  useEffect(() => {
    if (ready) saveItem(KEYS.THEME, isDark);
  }, [isDark, ready]);

  const isFavorite = useCallback((id) => favorites.some((c) => c.id === id), [favorites]);

  const toggleFavorite = useCallback((character) => {
    setFavorites((prev) =>
      prev.some((c) => c.id === character.id)
        ? prev.filter((c) => c.id !== character.id)
        : [character, ...prev]
    );
  }, []);

  const clearFavorites = useCallback(() => setFavorites([]), []);
  const toggleTheme = useCallback(() => setIsDark((d) => !d), []);

  return (
    <AppContext.Provider
      value={{ favorites, isFavorite, toggleFavorite, clearFavorites, isDark, toggleTheme, ready }}
    >
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
