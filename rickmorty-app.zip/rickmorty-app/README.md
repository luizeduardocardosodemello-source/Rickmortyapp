# Rick & Morty Explorer (React Native + Expo)

## Como rodar

```bash
# 1. Crie o projeto base
npx create-expo-app@latest rickmorty-app --template blank
cd rickmorty-app

# 2. Instale as dependências (versões compatíveis com seu SDK)
npx expo install react-native-paper @react-navigation/native \
  @react-navigation/native-stack @react-navigation/bottom-tabs \
  react-native-screens react-native-safe-area-context \
  @react-native-async-storage/async-storage @expo/vector-icons

# 3. Substitua o App.js e copie a pasta src/ deste projeto

# 4. Rode
npx expo start
```

## Requisitos da atividade

| Requisito | Onde |
|---|---|
| Consumo de API | `src/services/api.js` (lista paginada + busca + detalhe de episódio) |
| Navegação | `src/navigation/index.js` (Stack + Bottom Tabs) |
| React Native Paper | Todas as telas (Card, Searchbar, Chip, FAB, List, MD3 tema claro/escuro) |
| AsyncStorage | `src/storage/storage.js` + `src/context/AppContext.js` (favoritos e tema) |
