import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { PaperProvider, MD3DarkTheme, MD3LightTheme, ActivityIndicator } from 'react-native-paper';
import { View } from 'react-native';
import { AppProvider, useApp } from './src/context/AppContext';
import Navigation from './src/navigation';

function Root() {
  const { isDark, ready } = useApp();
  const theme = isDark ? MD3DarkTheme : MD3LightTheme;

  // Espera o AsyncStorage carregar (tema + favoritos) antes de renderizar
  if (!ready) {
    return (
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <PaperProvider theme={theme}>
      <Navigation theme={theme} />
      <StatusBar style={isDark ? 'light' : 'dark'} />
    </PaperProvider>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <Root />
      </AppProvider>
    </SafeAreaProvider>
  );
}
